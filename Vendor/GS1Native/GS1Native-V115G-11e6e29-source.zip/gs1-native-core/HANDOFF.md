# GS1 V115G Native core — передача в интеграцию

Дата: 31.10.2026. Связи: `README.md`, `NOTICE.md`,
`../cgm-driver-research-expanded/gs1-integration/jugglucong/REVIEW.md`.

Собран **GS1Native.xcframework** для iPhone ARM64 и iOS Simulator ARM64:
`build/GS1Native.xcframework`. Это статический framework с Kotlin/Native runtime;
не требует JVM на телефоне. Рабочий xDrip не изменён.

## Что вошло

Pinned GPL3 JugglucoNG `11e6e29db7d9055c8fd2e96261812e16f2095f3d`:
ExactV115GCore, ExactV115GClip и две observation-модели. Алгоритмические выражения
не менялись; механический diff — `evidence/mechanical-port.diff` (53 строки).
V116A сохранён для дальнейшего аудита, но в framework не включён.

Swift API — `GS1V115GEngine(sensorIdentity:factorySensitivity:)`,
`accept(rawMmol:temperatureC:index:)`, `snapshot()`, `restore(snapshot:)`.
Полный работающий пример — `tests/SwiftImportSmoke.swift`.

Только `.correction` + ненулевой `finalMmol` возвращает финальный core-результат.
Промежуточные минуты и abnormal-ветки дают nil. Минутного raw/delta fallback нет.
Finite raw0 продвигает индекс без публикации. После первого принятого индекса
разрешён только следующий; пропуск требует backfill внешним драйвером.

Snapshot envelopev2 проверяет полный source SHA/семейство/compatrevision,
sensorIdentity, sensitivity, lastIndex и CRC32. Restore сначала проверяет отдельный
candidate, поэтому повреждённый файл не меняет активное состояние.

## Что измерено

| Проверка | Результат |
|---|---|
| Публичная CSV, 15 765 минутных входов | 3 153 vendor-oracle совпадения, максимальная ошибка0.0mmol/L |
| Выдача final correction | 3 152 ненулевых результата; исходный0 на index25 отфильтрован |
| JVM original → Native port | 9 155/9 155 checkpoints идентичны: finalFloatbits и hash полного core snapshot |
| Синтетический cold start | 30 000 входов при sensitivity0.8/2.5, включены в differential trace |
| Продолжение после snapshot | 8 290 строк совпали после восстановления перед index7500 |
| Guards | identity/sensitivity mismatch, CRC/truncation, duplicate/gap/NaN, zero→next проверены |
| Swift bridge | iOS typecheck; macOS executable реально вызвал core, snapshot↔Data и98 строк продолжения |
| Framework | iOS ARM64 + Simulator ARM64 успешно скомпилированы и упакованы |

Машиночитаемые результаты: `evidence/validation-summary.json`,
`evidence/differential-result.json`; полный trace — `evidence/replay-{jvm,macos}.log`.
Хеши framework и источников — `evidence/xcframework-manifest.json` и
`evidence/local-source-hashes.json`. Toolchain2.4.21/JDK21 скачан официально и
проверен SHA256, хранится только здесь; manifest — `evidence/toolchain-manifest.json`.

## Что должен обеспечить xDrip-адаптер

1. Подтвердить поддерживаемый GS1 protocol/algorithm family; не направлять GS1EU,
   GS3 или неизвестный encrypted sensor в V115G по названию/цвету коробки.
2. Валидировать BLE кадры, status, checksum, identity, чувствительность и минутный индекс.
3. Воспроизвести непрерывную историю; запуск CSV с index25 не подтверждает полноту
   реального cold start. Допуск первого индекса в core — низкоуровневый контракт.
4. Применить подтверждённый прогрев и lifecycle, дать исходную дату измерения,
   исключить future/stale/duplicate, не превращать history в актуальную точку.
5. Сериализовать вызовы core и сохранить snapshot с привязкой к сенсору.
6. Передавать в CGM/Trio только допущенные адаптером final corrections.

Реальный датчик, активация, BLE reconnect и runtime на iPhone здесь не проверялись.
Набор тестов доказывает программное совпадение с pinned JVM и публичным oracle,
но не клиническую точность и не поддержку каждого GS1.

## Ограничение варианта и фактического подключения

Первая интеграция предназначена для **заводского GS1 CN с семейством115G**.
Она не подтверждает перезапущенные/продлённые сенсоры, GS1EU/V120, GS3 и
неизвестные encrypted-версии. Название GS1, AA55 или жёлтая коробка по отдельности
не определяют семейство. Китайская инструкция B9 (март2026), страницы PDF23–24,
подтверждает **60минут прогрева и пятиминутные показания**. Документ перечисляет
GS1, GS1-10 и GS1-7; предел14дней применим только к соответствующей заводской
модели, а не автоматически ко всем CN-сенсорам.
[Официальная инструкция](https://protocol.sisensing.com/sijoy_instructions/web/GS1%E6%8C%81%E7%BB%AD%E8%91%A1%E8%90%84%E7%B3%96%E7%9B%91%E6%B5%8B%E7%B3%BB%E7%BB%9F%E4%BD%BF%E7%94%A8%E8%AF%B4%E6%98%8E%E4%B9%A6.pdf).

**Источник Bluetooth MAC остаётся существенным условием подключения.**
Android upstream берёт `mActiveDeviceAddress` из `BluetoothDevice.address` и
вставляет перевёрнутые шесть байт в AA5507. QR decoder не возвращает MAC;
CoreBluetooth UUID его не заменяет. Подтверждённого извлечения MAC из iOS
advertisement либо успешного CN-чтения с нулевым MAC пока нет. В первой iOS
интеграции нужен вручную введённый MAC из независимо проверенного источника.
Сам факт успешного scan/select ещё не подтверждает правильность MAC и соединения.
Исходный путь: [SibionicsBleManager.kt](https://github.com/ctqvva/JugglucoNG/blob/11e6e29db7d9055c8fd2e96261812e16f2095f3d/Common/src/main/java/tk/glucodata/drivers/sibionics/SibionicsBleManager.kt).

При переносе сохранять `LICENSE.txt`, `NOTICE.md`, source revision и изменённые
исходники/сборочный рецепт. Никаких покупок, глобальных установок или изменений
помпы не выполнено.

Для длительного хранения подготовлен `GS1Native-V115G-11e6e29-source.zip`:
исходники, publicfixtures, лицензия, проверочный trace, manifests и рецепт сборки.
Toolchain/downloads/готовые бинарники в него не входят. Восстановление описано
в `REBUILD.md`; framework не менялся при упаковке.

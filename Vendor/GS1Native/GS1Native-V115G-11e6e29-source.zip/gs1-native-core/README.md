# GS1 V1.1.5G: изолированный Kotlin/Native core

Связанные материалы: `../cgm-driver-research-expanded/gs1-integration/swift-audit.md`
и `../cgm-driver-research-expanded/gs1-integration/jugglucong/REVIEW.md`.

Это перенос вычислительного ядра, а не готовый CGM-драйвер. Рабочий xDrip,
датчики, помпа и пользовательские данные не изменяются.

## Граница реализации

- Pinned JugglucoNG `11e6e29db7d9055c8fd2e96261812e16f2095f3d`.
- Только ExactV115GCore + ExactV115GClip. V116A сохранён для аудита, в бинарник не входит.
- Арифметика исходников сохранена; изменения только в Java/common совместимости.
- Нет BLE, активации, QR, выбора версии протокола, часов датчика и передачи в Trio.
- Каждая минутная точка поступает в core. Публикуется только финальная correction
  на пятиминутном шаге; raw fallback и минутный delta-carry отсутствуют.
- NO_CORRECTION включает как промежуточную минуту, так и отклонённую core точку.
- Порядок вызовов должен быть последовательным. Первый индекс задаёт вызывающий
  код; затем принимается только `lastIndex + 1`. Полноту первоначальной истории
  и прогрев обеспечивает внешний драйвер.
- Snapshot содержит identity, sensitivity, алгоритм/версию envelope, последний
  индекс и CRC32; неудачный restore сохраняет текущий core без изменений.
  CRC предназначен для повреждения файла, а не аутентификации.
- Finite raw0 проходит в неизменённый core и продвигает индекс без публикации.
- Envelopev2 содержит полный pinned source SHA и compatrevision.

## Swift-facing API

`GS1V115GEngine(sensorIdentity:factorySensitivity:)` создаёт отдельный core.
`accept(rawMmol:temperatureC:index:)` возвращает GS1CoreResult с `status`,
`sensorIndex`, `finalMmol`. Только `CORRECTION` содержит пригодный по контракту
core финальный результат; это ещё не разрешение публикации в CGM.

`snapshot()` / `restore(snapshot:)` используют KotlinByteArray. Перенос snapshot
между разными identity или sensitivity отклоняется. `lastAcceptedIndex` позволяет
внешнему драйверу продолжить backfill. Методы не предназначены для конкурентных
вызовов; адаптер должен работать на одной последовательной очереди.

## Проверка без пользовательских данных

Публичный `sibionics_exact_v115g_replay.csv` содержит 15 765 строк, index25…15789.
Upstream тест сравнивает **vendor_mmol, четвёртый столбец**, только на index%5==0:
3 153 ожидаемых результата. Столбец exact_mmol не является используемым oracle.
Replay начинается с25; полный cold start index1…24 этой выборкой не покрыт.

`tests/Replay.kt` проверяет:

1. Каждый vendor oracle с исходным допуском0.0001mmol/L.
2. Нулевые промежуточные результаты, отсутствие raw fallback.
3. Восстановление core и façade перед index7500, одинаковое продолжение.
4. Дубликаты, gaps, NaN, несовпадающий sensor/sensitivity, повреждённый checkpoint.
5. JVM vs Native: финальные Float bit patterns и hash полного core snapshot на
   каждом correction; любое отличие сохраняется для разбора.

Оригинальные JVM core/clip для сравнения берутся из `upstream/`, а не из порта.
Это проверка программного совпадения, не клиническая валидация и не проверка
реального сенсора или нового зашифрованного протокола.

## Локальная сборка

Toolchain лежит только в `toolchains/`. Системные профили, Homebrew и глобальные
настройки Java не используются. Команды запускаются из этой папки:

```sh
python3 build.py jvm
python3 build.py mac
python3 build.py compare
python3 build.py ios
```

Опционально `python3 build.py iossim` для iOS Simulator ARM64.
Логи и сравнение — `evidence/`; framework — `build/iosArm64/GS1Native.framework`.
Готовый bundle обеих iOS-архитектур — `build/GS1Native.xcframework`.
Итог измерений и границы внедрения — `HANDOFF.md`.

Документация компилятора:
https://kotlinlang.org/docs/apple-framework.html

Происхождение и лицензия: `NOTICE.md`, `evidence/source-manifest.json`.

# Воспроизводимая сборка из source-only архива

Связи: `README.md`, `HANDOFF.md`, `NOTICE.md`.

Нужен Mac AppleSilicon, установленный Xcode и Python3. Архив не содержит Java,
Kotlin, LLVM, downloads, framework или пользовательских данных. Все исходники
алгоритма и publicfixtures уже внутри; GitHub checkout проекта не требуется.

Проверить хеш архива по соседнему `.sha256`, распаковать в отдельную папку и
работать из неё. Хеши каждого включённого файла — `SOURCE_BUNDLE_MANIFEST.json`.

```sh
python3 bootstrap_toolchain.py
python3 build.py jvm
python3 build.py mac
python3 build.py compare
python3 build.py ios
python3 build.py iossim
```

`bootstrap_toolchain.py` скачивает три pinned официальных пакета, проверяет SHA256
до распаковки и помещает их в локальные `downloads/` и `toolchains/`. Первый
Kotlin/Native запуск дополнительно получает LLVM/LLDB/libffi от JetBrains в
`toolchains/konan-data/`. Системная Java, shell-профили и xcode-select не меняются.
`build.py` задаёт `DEVELOPER_DIR=/Applications/Xcode.app/Contents/Developer`
только дочернему процессу; если Xcode находится в другом месте, изменить эту
единственную локальную строку. Скрипты чужого Android-проекта не запускаются.

Ожидаемый результат `build.py compare`: 9 155 trace checkpoints, 0 отличий;
3 153 oracle результата, maxError0.0; 8 290 строк после restore.
Native test читает ASCII CSV через POSIXgetchar; это обходит наблюдённый сбой
стандартного readLine с разделением redirectedstdin на4KB блоки. Алгоритм от
этого не меняется. Любое численное расхождение требует разбора, не увеличения
допуска.

Упаковать iOS framework:

```sh
env DEVELOPER_DIR=/Applications/Xcode.app/Contents/Developer \
  /Applications/Xcode.app/Contents/Developer/usr/bin/xcodebuild \
  -create-xcframework \
  -framework build/iosArm64/GS1Native.framework \
  -framework build/iosSimulatorArm64/GS1Native.framework \
  -output build/GS1Native.xcframework
```

Команда требует отсутствующего outputкаталога; существующий результат хранить
отдельно при сравнении сборок. API smoke — `tests/SwiftImportSmoke.swift`,
дополнительная macOSсборка — `python3 build.py macframework`.

Воспроизводимость означает проверяемый source/toolchain и одинаковые вычисления.
Битовая идентичность целого Appleframework при другом Xcode/SDK не заявляется;
manifest исходного результата хранится в `evidence/xcframework-manifest.json`.
Сборка31.10.2026 использовала Xcode SDK27.0.

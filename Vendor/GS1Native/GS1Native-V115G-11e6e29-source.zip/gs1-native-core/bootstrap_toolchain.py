#!/usr/bin/env python3
"""Download only the pinned official toolchain, locally; never change system Java/Xcode."""
from pathlib import Path
import hashlib, json, subprocess, urllib.request

ROOT = Path(__file__).resolve().parent
PACKAGES = (
    ('kotlin-native-prebuilt-macos-aarch64-2.4.21.tar.gz',
     'https://github.com/JetBrains/kotlin/releases/download/v2.4.21/kotlin-native-prebuilt-macos-aarch64-2.4.21.tar.gz',
     'bf4edb526d91e17d0862102f69250525d788e79011f86c2c64362749adf260ae'),
    ('kotlin-compiler-2.4.21.zip',
     'https://github.com/JetBrains/kotlin/releases/download/v2.4.21/kotlin-compiler-2.4.21.zip',
     '7cc140e76daf416a0424a5557f99afd7ca89ebd463ea1101261e3e01c33e75cd'),
    ('OpenJDK21U-jdk_aarch64_mac_hotspot_21.0.13_9.tar.gz',
     'https://github.com/adoptium/temurin21-binaries/releases/download/jdk-21.0.13%2B9/OpenJDK21U-jdk_aarch64_mac_hotspot_21.0.13_9.tar.gz',
     'bf036b35b071bfb2f54f2c0af8ee8d88afa95ee6eb3dce02c0f94cfc2524d04a'),
)

def sha256(path):
    digest = hashlib.sha256()
    with path.open('rb') as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b''):
            digest.update(block)
    return digest.hexdigest()

def main():
    downloads = ROOT / 'downloads'
    toolchains = ROOT / 'toolchains'
    downloads.mkdir(exist_ok=True)
    toolchains.mkdir(exist_ok=True)
    recorded = []
    for name, url, expected in PACKAGES:
        archive = downloads / name
        if not archive.exists() or sha256(archive) != expected:
            partial = downloads / (name + '.partial')
            print('Downloading official package:', name, flush=True)
            with urllib.request.urlopen(url, timeout=60) as source, partial.open('wb') as target:
                for block in iter(lambda: source.read(1024 * 1024), b''):
                    target.write(block)
            if sha256(partial) != expected:
                raise RuntimeError('SHA256 mismatch; refusing extraction: ' + name)
            partial.replace(archive)
        stamp = toolchains / (name + '.extracted')
        if not stamp.exists() or stamp.read_text().strip() != expected:
            # Extraction is reached only after matching the pinned official SHA256.
            command = ['unzip', '-oq', str(archive), '-d', str(toolchains)] if name.endswith('.zip') else ['tar', '-xzf', str(archive), '-C', str(toolchains)]
            subprocess.run(command, check=True)
            stamp.write_text(expected + '\n')
        recorded.append({'name': name, 'url': url, 'sha256': expected, 'verified': True})
    (ROOT / 'evidence').mkdir(exist_ok=True)
    (ROOT / 'evidence/rebuild-toolchain-manifest.json').write_text(json.dumps(recorded, indent=2) + '\n')
    print('Pinned toolchain is ready in', toolchains)

if __name__ == '__main__':
    main()

package gs1.tests

fun fixtureLines(): List<String> = generateSequence(::readlnOrNull).toList()

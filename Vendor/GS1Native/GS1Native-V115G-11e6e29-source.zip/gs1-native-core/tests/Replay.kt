package gs1.tests

import gs1.nativecore.GS1V115GEngine
import gs1.nativecore.GS1CoreStatus
import tk.glucodata.drivers.sibionics.SibionicsExactV115GCore
import kotlin.math.abs

private data class Row(val index: Int, val raw: Float, val temperature: Float, val vendor: Float)
private fun hash(bytes: ByteArray): String {
    var h = 0xcbf29ce484222325UL
    bytes.forEach { h = (h xor (it.toUByte().toULong())) * 0x100000001b3UL }
    return h.toString(16)
}

/** Public upstream fixture only. The fourth CSV column is the upstream test oracle. */
fun main(args: Array<String>) {
    val dump = args.contains("--dump")
    val rows = fixtureLines().drop(1).filter { it.isNotEmpty() }.map { line ->
        val f = line.split(',')
        fun fieldFloat(i: Int): Float = f[i].toFloatOrNull() ?: error("Public fixture Float parse failed: field=$i text='${f[i]}' line='$line'")
        val index = f[0].toIntOrNull() ?: error("Public fixture index parse failed: '${f[0]}' line='$line'")
        Row(index, fieldFloat(1), fieldFloat(2), fieldFloat(3))
    }.toList()
    check(rows.size == 15765 && rows.first().index == 25 && rows.last().index == 15789)
    val core = SibionicsExactV115GCore(1.40f)
    val restored = SibionicsExactV115GCore(1.40f)
    val engine = GS1V115GEngine("public-fixture", 1.40f)
    val restoredEngine = GS1V115GEngine("public-fixture", 1.40f)
    var count = 0
    var restoredCount = 0
    var maxError = 0f
    var firstMismatch: String? = null
    var mismatchCount = 0
    var engineCount = 0
    val checkpoints = setOf(30, 100, 7499, 7500, 10000, 15789)
    for (row in rows) {
        if (row.index == 7500) {
            check(restored.restore(core.snapshot()))
            check(restoredEngine.restore(engine.snapshot()!!))
            check(restored.snapshot().contentEquals(core.snapshot()))
        }
        val actual = core.process(row.raw, row.temperature, row.index)
        val result = engine.accept(row.raw, row.temperature, row.index)
        if (actual == null) {
            check(row.index % 5 != 0) { "Missing correction at ${row.index}" }
            check(result.status == GS1CoreStatus.NO_CORRECTION)
            check(result.finalMmol == null)
        } else {
            check(row.index % 5 == 0)
            count++
            val error = abs(actual - row.vendor)
            maxError = maxOf(maxError, error)
            if (error > 0.0001f) {
                mismatchCount++
                if (firstMismatch == null) firstMismatch = "index=${row.index}, actual=$actual, vendor=${row.vendor}"
            }
            if (actual.isFinite() && actual > 0f && actual <= 50f) {
                check(result.status == GS1CoreStatus.CORRECTION && result.finalMmol == actual)
                engineCount++
            } else {
                check(result.status == GS1CoreStatus.INVALID_OUTPUT && result.finalMmol == null)
            }
        }
        if (row.index >= 7500) {
            val r = restored.process(row.raw, row.temperature, row.index)
            check(actual?.toRawBits() == r?.toRawBits()) { "Restore output differs at ${row.index}" }
            val re = restoredEngine.accept(row.raw, row.temperature, row.index)
            check(re.status == result.status && re.finalMmol?.toRawBits() == result.finalMmol?.toRawBits())
            restoredCount++
        }
        if (dump && (actual != null || row.index in checkpoints)) {
            println("TRACE,${row.index},${actual?.toRawBits() ?: "null"},${hash(core.snapshot())}")
        }
        if (row.index in checkpoints) {
            check(core.snapshot().contentEquals(if (row.index >= 7500) restored.snapshot() else core.snapshot()))
        }
    }
    check(count == 3153)
    // Rejected calls must not advance or corrupt the ordered engine state.
    val before = engine.snapshot()!!
    check(engine.accept(10f, 33f, 15789).status == GS1CoreStatus.NON_CONTIGUOUS_INDEX)
    check(engine.accept(10f, 33f, 15791).status == GS1CoreStatus.NON_CONTIGUOUS_INDEX)
    check(engine.accept(Float.NaN, 33f, 15790).status == GS1CoreStatus.INVALID_INPUT)
    check(before.contentEquals(engine.snapshot()!!))
    check(!GS1V115GEngine("other-sensor", 1.40f).restore(before))
    check(!GS1V115GEngine("public-fixture", 1.27f).restore(before))
    val corrupted = before.copyOf().also { it[it.size / 2] = (it[it.size / 2].toInt() xor 1).toByte() }
    check(!engine.restore(corrupted))
    check(!engine.restore(before.copyOf(before.size - 1)))
    check(before.contentEquals(engine.snapshot()!!))
    check(GS1V115GEngine("", 1.40f).accept(10f, 33f, 1).status == GS1CoreStatus.INVALID_CONFIGURATION)
    check(GS1V115GEngine("id", Float.NaN).accept(10f, 33f, 1).status == GS1CoreStatus.INVALID_CONFIGURATION)
    val zeroEngine = GS1V115GEngine("zero-startup", 1.40f)
    check(zeroEngine.accept(0f, 33f, 1).status == GS1CoreStatus.NO_CORRECTION)
    check(zeroEngine.lastAcceptedIndex == 1)
    check(zeroEngine.accept(10f, 33f, 2).status == GS1CoreStatus.NO_CORRECTION)
    check(zeroEngine.lastAcceptedIndex == 2)
    // Deterministic cold-start inputs contain no personal data. These are only
    // a JVM/Native differential corpus, not a manufacturer accuracy oracle.
    for (sensitivity in listOf(0.8f, 2.5f)) {
        val synthetic = SibionicsExactV115GCore(sensitivity)
        for (index in 1..15000) {
            val triangle = if ((index / 100) % 2 == 0) index % 100 else 100 - index % 100
            val raw = (50 + triangle).toFloat() / 10f
            val temperature = (280 + (index / 30) % 91).toFloat() / 10f
            val value = synthetic.process(raw, temperature, index)
            if (dump && index % 5 == 0) {
                println("TRACE,synthetic-$sensitivity-$index,${value?.toRawBits() ?: "null"},${hash(synthetic.snapshot())}")
            }
        }
    }
    println("RESULT rows=${rows.size} corrections=$count emitted=$engineCount oracleMismatches=$mismatchCount maxError=$maxError restoredRows=$restoredCount finalStateHash=${hash(core.snapshot())}")
    check(mismatchCount == 0) { "Vendor oracle mismatch: $firstMismatch" }
}

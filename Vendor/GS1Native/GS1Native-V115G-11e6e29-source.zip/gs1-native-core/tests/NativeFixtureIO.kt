package gs1.tests

import platform.posix.getchar

/** Read ASCII fixture bytes explicitly; no line-reader buffering assumptions. */
fun fixtureLines(): List<String> {
    val lines = mutableListOf<String>()
    var line = StringBuilder()
    while (true) {
        val byte = getchar()
        if (byte < 0) break
        if (byte == 10) { lines.add(line.toString()); line = StringBuilder() }
        else if (byte != 13) line.append(byte.toChar())
    }
    if (line.isNotEmpty()) lines.add(line.toString())
    return lines
}

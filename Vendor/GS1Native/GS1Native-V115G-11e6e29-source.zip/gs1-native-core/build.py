#!/usr/bin/env python3
"""Local, explicit build recipe. Runs only pinned official Kotlin/JDK binaries."""
from pathlib import Path
import os, subprocess, sys, json

ROOT = Path(__file__).resolve().parent
(ROOT / 'build').mkdir(exist_ok=True)
(ROOT / 'evidence').mkdir(exist_ok=True)
NATIVE = ROOT / 'toolchains/kotlin-native-prebuilt-macos-aarch64-2.4.21/bin/kotlinc-native'
JVM = ROOT / 'toolchains/kotlinc/bin/kotlinc'
JDK = ROOT / 'toolchains/jdk-21.0.13+9/Contents/Home'
ENV = os.environ.copy()
ENV['JAVA_HOME'] = str(JDK)
ENV['KONAN_DATA_DIR'] = str(ROOT / 'toolchains/konan-data')
ENV['JAVA_OPTS'] = '-Xmx4g'
ENV['DEVELOPER_DIR'] = '/Applications/Xcode.app/Contents/Developer'
SOURCES = sorted((ROOT / 'src').glob('*.kt'))
BASE = ROOT / 'upstream/Common/src/main/java/tk/glucodata/drivers/sibionics'
FIXTURE = ROOT / 'upstream/Common/src/test/resources/sibionics_exact_v115g_replay.csv'

def run(name, command, stdin=None):
    log = ROOT / 'evidence' / f'{name}.log'
    print(f'{name}: started', flush=True)
    with log.open('w') as out:
        result = subprocess.run([str(x) for x in command], cwd=ROOT, env=ENV, stdin=stdin, stdout=out, stderr=subprocess.STDOUT)
    print(f'{name}: exit {result.returncode}; {log}', flush=True)
    if result.returncode:
        print(log.read_text()[-12000:], flush=True)
        raise SystemExit(result.returncode)

action = sys.argv[1] if len(sys.argv) > 1 else 'all'
if action in ('jvm', 'all'):
    original = [BASE / 'SibionicsExactV115GCore.kt', BASE / 'SibionicsExactV115GClip.kt']
    bridge = [ROOT / 'src/SibionicsObservations.kt', ROOT / 'src/JvmCompat.kt', ROOT / 'src/GS1V115GEngine.kt']
    run('build-jvm', [JVM, *original, *bridge, ROOT / 'tests/Replay.kt', ROOT / 'tests/JvmFixtureIO.kt', '-include-runtime', '-d', ROOT / 'build/v115g-jvm.jar'])
    with FIXTURE.open('r') as source:
        run('replay-jvm', [JDK / 'bin/java', '-jar', ROOT / 'build/v115g-jvm.jar', '--dump'], source)
if action in ('mac', 'all'):
    run('build-macos', [NATIVE, *SOURCES, ROOT / 'tests/Replay.kt', ROOT / 'tests/NativeFixtureIO.kt', '-target', 'macos_arm64', '-produce', 'program', '-entry', 'gs1.tests.main', '-o', ROOT / 'build/v115g-replay'])
    with FIXTURE.open('r') as source:
        run('replay-macos', [ROOT / 'build/v115g-replay.kexe', '--dump'], source)
if action in ('ios', 'all'):
    (ROOT / 'build/iosArm64').mkdir(parents=True, exist_ok=True)
    run('build-ios', [NATIVE, *SOURCES, '-target', 'ios_arm64', '-produce', 'framework', '-Xstatic-framework', '-Xbinary=bundleId=local.gs1.nativecore', '-o', ROOT / 'build/iosArm64/GS1Native'])
if action == 'iossim':
    (ROOT / 'build/iosSimulatorArm64').mkdir(parents=True, exist_ok=True)
    run('build-iossim', [NATIVE, *SOURCES, '-target', 'ios_simulator_arm64', '-produce', 'framework', '-Xstatic-framework', '-Xbinary=bundleId=local.gs1.nativecore', '-o', ROOT / 'build/iosSimulatorArm64/GS1Native'])
if action == 'macframework':
    (ROOT / 'build/macosArm64').mkdir(parents=True, exist_ok=True)
    run('build-macos-framework', [NATIVE, *SOURCES, '-target', 'macos_arm64', '-produce', 'framework', '-Xstatic-framework', '-Xbinary=bundleId=local.gs1.nativecore', '-o', ROOT / 'build/macosArm64/GS1Native'])
if action in ('compare', 'all'):
    jvm = (ROOT / 'evidence/replay-jvm.log').read_text().splitlines()
    mac = (ROOT / 'evidence/replay-macos.log').read_text().splitlines()
    jvm_trace = [x for x in jvm if x.startswith('TRACE,')]
    mac_trace = [x for x in mac if x.startswith('TRACE,')]
    differences = [(a,b) for a,b in zip(jvm_trace, mac_trace) if a != b]
    result = {'jvm_trace_rows': len(jvm_trace), 'native_trace_rows': len(mac_trace), 'different_rows': len(differences), 'first_differences': differences[:10], 'jvm_result': [x for x in jvm if x.startswith('RESULT ')], 'native_result': [x for x in mac if x.startswith('RESULT ')]}
    (ROOT / 'evidence/differential-result.json').write_text(json.dumps(result, indent=2) + '\n')
    print(json.dumps(result, indent=2))
    if len(jvm_trace) != len(mac_trace) or differences:
        raise SystemExit(1)
